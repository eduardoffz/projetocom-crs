package Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Aluno
 */
public class conexao {
    
    private static final String URL  = "jdbc:mysql://localhost:3337/funcionarios";
    private static final String USER = "root";
    private static final String SENHA = "";
    private static Connection conn = null;
    
    private conexao() {
    }
   
    public static synchronized Connection conectar() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(URL, USER, SENHA);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
