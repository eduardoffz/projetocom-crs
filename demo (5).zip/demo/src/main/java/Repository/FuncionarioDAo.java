package Repository;

import Model.FuncionarioBean;
import static Repository.conexao.conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList; 
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public class FuncionarioDAo { 
    
    public List<FuncionarioBean> lerTodos() {
        List<FuncionarioBean> dados = new ArrayList<>();
        
        try (Connection conn = conectar();
            
                
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM funcionario");
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                FuncionarioBean funcionario = new FuncionarioBean();
                funcionario.setId(rs.getInt("id")); 
                funcionario.setNome(rs.getString("nome"));
                funcionario.setCargo(rs.getString("cargo"));
                funcionario.setDepartamento(rs.getString("departamento"));
                funcionario.setDatacontratacao(rs.getDate("data_contratacao"));

                funcionario.setEmail(rs.getString("email"));
                
                dados.add(funcionario); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return dados;
        
    }
    

    
    
    
    
    
    
    
    
    
    
   
    
    
    public FuncionarioBean lerPorId(int id) {
    FuncionarioBean funcionario = null;

    
    try (Connection conn = conectar();
         PreparedStatement stmt = conn.prepareStatement("SELECT * FROM funcionario WHERE id = ?")) {
        
      
        
        stmt.setInt(1, id);
     
        try (ResultSet rs = stmt.executeQuery()) {
            
            if (rs.next()) {
               
                
                funcionario = new FuncionarioBean();
                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
                funcionario.setCargo(rs.getString("cargo"));
                funcionario.setDepartamento(rs.getString("departamento"));
                funcionario.setDatacontratacao(rs.getDate("datacontratacao")); 
                
                funcionario.setEmail(rs.getString("email"));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return funcionario;
}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    List<FuncionarioBean> LerTodos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
