package Service;

import Model.FuncionarioBean;
import Repository.FuncionarioDAo;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FuncionarioService {
    
    private final FuncionarioDAo repository;
    
    @Autowired
    public FuncionarioService(FuncionarioDAo repository) {
        this.repository = repository;
        
    }
    
    
    
    public List<FuncionarioBean> listarTodos() {
        return repository.lerTodos();
    }

    
    public List<FuncionarioBean> LerTodos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

public FuncionarioBean LerPorId(int id){
return repository.Lerporid(id);
}

