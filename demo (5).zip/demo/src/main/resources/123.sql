CREATE TABLE funcionarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    cargo VARCHAR(100),
    departamento VARCHAR(50),
    email VARCHAR(100),
    data_contratacao DATE
);

INSERT INTO funcionarios (nome, cargo, departamento, email, data_contratacao) VALUES
('Ana Silva', 'Desenvolvedora Front-end', 'Tecnologia', 'ana.silva@empresa.com', '2023-01-15'),
('Carlos Santos', 'Analista de Suporte', 'Tecnologia', 'carlos.santos@empresa.com', '2022-11-03'),
('Mariana Oliveira', 'Gerente de Projetos', 'Diretoria', 'mariana.oliveira@empresa.com', '2021-08-20'),
('João Pedro', 'Desenvolvedor Back-end', 'Tecnologia', 'joao.pedro@empresa.com', '2023-05-10'),
('Fernanda Lima', 'Analista de RH', 'Recursos Humanos', 'fernanda.lima@empresa.com', '2020-02-28'),
('Lucas Almeida', 'Assistente Administrativo', 'Administração', 'lucas.almeida@empresa.com', '2024-01-05'),
('Beatriz Costa', 'Designer UX/UI', 'Tecnologia', 'beatriz.costa@empresa.com', '2023-07-12');






CREATE TABLE funcionarios (
    id INT PRIMARY KEY,
    nome VARCHAR(100),
    cargo VARCHAR(100),
    departamento VARCHAR(10),
    email VARCHAR(100),
    data_contratacao DATE
);
