package Repository;

import Model.FuncionarioBean;
import static Repository.conexao.conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList; 
import java.util.List;

public class FuncionarioDAo { 
    
    public List<FuncionarioBean> lerTodos() {
        List<FuncionarioBean> dados = new ArrayList<>();
        
        try (Connection conn = conectar();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM funcionario");
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                FuncionarioBean funcionario = new FuncionarioBean();
                funcionario.setId(rs.getInt("id")); 
                funcionario.setNome(rs.getString("nome"));
                funcionario.setCargo(rs.getString("cargo"));
                funcionario.setDepartamento(rs.getString("departamento"));
                funcionario.setDatacontratacao(rs.getDate("data_contratacao"));
                funcionario.setEmail(rs.getString("email"));
                
                dados.add(funcionario); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return dados;
    }
}
